import React, { Component } from "react";

class Left extends Component {
  render() {
    return (
      //Left 영역 s
      <div className="col-lg-2" id="lay_left">
        <p>LEFT</p>
      </div>
      //Left 영역 e
    );
  }
}
export default Left;
