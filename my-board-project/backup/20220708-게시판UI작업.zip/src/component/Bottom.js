import React, { Component } from "react";

class Bottom extends Component {
  render() {
    return (
      //Bottom 영역 s
      <div className="row" id="lay_bottom">
        <p>BOTTOM</p>
      </div>
      //Bottom 영역 e
    );
  }
}
export default Bottom;
