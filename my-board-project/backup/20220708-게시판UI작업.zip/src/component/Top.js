import React, { Component } from "react";

class Top extends Component {
  render() {
    return (
      //Top 영역 s
      <div className="row" id="lay_top">
        <p>TOP</p>
      </div>
      //Top 영역 e
    );
  }
}
export default Top;
