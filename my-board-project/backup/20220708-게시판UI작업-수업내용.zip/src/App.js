import React, { Component } from "react";
import "./App.css";
import Bottom from "./components/Bottom";
import Left from "./components/Left";
import Top from "./components/Top";
import ListContents from "./components/ListContents";
import ViewContents from "./components/ViewContents";
import WriteContents from "./components/WriteContents";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      content: [
        {
          id: 1,
          title: "여긴 제목1",
          desc: "여긴 내용1",
          views: 0,
          date: "2022. 7. 8",
        },
        {
          id: 2,
          title: "여긴 제목2",
          desc: "여긴 내용2",
          views: 0,
          date: "2022. 7. 8",
        },
        {
          id: 3,
          title: "여긴 제목3",
          desc: "여긴 내용3",
          views: 0,
          date: "2022. 7. 8",
        },
      ],
      mode: "list",
    };
  }

  render() {
    let contents;

    if (this.state.mode === "list") {
      contents = (
        <ListContents
          myChangeMode={(pmode) => {
            this.setState({
              mode: pmode,
            });
          }}
        ></ListContents>
      );
    } else if (this.state.mode === "write") {
      contents = (
        <WriteContents
          myChangeMode={(pmode) => {
            this.setState({
              mode: pmode,
            });
          }}
        ></WriteContents>
      );
    } else if (this.state.mode === "view") {
      contents = (
        <ViewContents
          myChangeMode={(pmode) => {
            this.setState({
              mode: pmode,
            });
          }}
        ></ViewContents>
      );
    }
    return (
      <div className="container">
        <Top></Top>
        <div className="row">
          <Left></Left>
          {/* mode에 따라 각기 다른 컴포넌트가 렌더링된다. */}
          {contents}
        </div>
        <Bottom></Bottom>
      </div>
    );
  }
}

export default App;
