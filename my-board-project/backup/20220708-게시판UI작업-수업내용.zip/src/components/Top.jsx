import { Component } from "react";

class Top extends Component {
  render() {
    return (
      <div className="row" id="lay_top">
        <p>TOP</p>
      </div>
    );
  }
}

export default Top;
