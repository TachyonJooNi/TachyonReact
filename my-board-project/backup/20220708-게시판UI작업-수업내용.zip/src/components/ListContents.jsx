import React, { Component } from "react";

export default class ListContents extends Component {
  render() {
    return (
      <div className="col-lg-10" id="lay_contents">
        <h2>게시판목록</h2>
        <table className="table table-bordered">
          <thead>
            <tr>
              <th width="10%">번호</th>
              <th width="*">제목</th>
              <th width="15%">작성자</th>
              <th width="15%">조회수</th>
              <th width="15%">작성일</th>
            </tr>
          </thead>
          <tbody>
            <tr align="center">
              <td>100</td>
              <td align="left">
                <a
                  href="/view"
                  onClick={(e) => {
                    // <a>태그를 눌렀을때 화면의 깜빡임 차단.
                    e.preventDefault();
                    // 게시물을 클릭하면 내용보기로 넘어가므로 'view'를 전달한다.
                    this.props.myChangeMode("view");
                  }}
                >
                  나는 제목
                </a>
              </td>
              <td align="center">홍길동</td>
              <td align="center">20</td>
              <td align="center">2020.02.20</td>
            </tr>
          </tbody>
        </table>
        <div align="right">
          <button
            type="button"
            onClick={(e) => {
              // <a>태그를 눌렀을때 화면의 깜빡임 차단.
              e.preventDefault();
              // 글쓰기를 클릭하면 작성페이지로 넘어가므로 'write'를 전달한다.
              this.props.myChangeMode("write");
            }}
          >
            글쓰기
          </button>
        </div>
      </div>
    );
  }
}
