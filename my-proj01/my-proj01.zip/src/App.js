import "./App.css";
import React, { Component } from "react";
import Comtable from "./com/table";
import ComNavi from "./com/navi";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      first: [{ title: "FirstName" }, { title: "Joon" }, { title: "Hee" }],
      last: { subtitle: "LastName" },
      email: "xxx@naver.com",
    };
  }
  render() {
    return (
      <div className="App">
        <ComNavi></ComNavi>
        <Comtable
          first={this.state.first}
          last={this.state.last.subtitle}
          email={this.state.email}
          onChangeEmail={() => {
            this.setState({ email: "madcatz@naver.com" });
          }}
          onChangeName={() => this.setState({})}
        ></Comtable>
      </div>
    );
  }
}

export default App;
