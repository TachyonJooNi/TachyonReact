import React, {Component} from "react";

class ComNavi extends Component {
  render() {
    return (
      <div>Navi</div>
    )
  }
}

export default ComNavi;